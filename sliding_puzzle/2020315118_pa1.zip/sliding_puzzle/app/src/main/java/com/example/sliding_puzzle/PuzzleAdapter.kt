package com.example.sliding_puzzle

import android.content.Context
import android.graphics.Bitmap
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView

class PuzzleAdapter(private val context: Context, private val pieces: List<Bitmap?>) : BaseAdapter() {

    override fun getCount(): Int = pieces.size

    override fun getItem(position: Int): Any? = pieces[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val imageView = convertView as? ImageView ?: ImageView(context)

        // Calculate the size of the puzzle piece based on the parent view's size
        parent?.let {
            val gridSize = Math.sqrt(pieces.size.toDouble()).toInt() // Calculate the rows/columns in the puzzle
            val pieceSize = (it.width / gridSize) // Calculate the size of each piece
            val margin = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                1f,
                context.resources.displayMetrics
            ).toInt() // convert 1dp margin to px

            val layoutParams = ViewGroup.MarginLayoutParams(pieceSize, pieceSize).apply {
                setMargins(margin, margin, margin, margin)
            }
            imageView.layoutParams = layoutParams
        }

        imageView.scaleType = ImageView.ScaleType.CENTER_CROP

        val piece = pieces[position]
        if (piece != null) {
            imageView.setImageBitmap(piece)
        } else {
            imageView.setImageResource(android.R.color.transparent) // the empty piece
        }
        return imageView
    }
}