package com.example.sliding_puzzle

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var puzzlePieces: MutableList<Bitmap?>
    private lateinit var adapter: PuzzleAdapter
    private lateinit var boardView: GridView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sliding_puzzle)
        boardView = findViewById(R.id.boardView)

        val button3x3 = findViewById<Button>(R.id.button)
        val button4x4 = findViewById<Button>(R.id.button2)
        val button5x5 = findViewById<Button>(R.id.button3)
        val shuffleButton = findViewById<Button>(R.id.button4)

        // Initialize 3x3 puzzle
        createPuzzle(3, 3)

        // Set button click events
        button3x3.setOnClickListener { createPuzzle(3, 3) }
        button4x4.setOnClickListener { createPuzzle(4, 4) }
        button5x5.setOnClickListener { createPuzzle(5, 5) }

        // Handle Shuffle button click event
        shuffleButton.setOnClickListener { shufflePuzzlePieces() }


// Convert the original image to Bitmap
        // 원본 이미지를 Bitmap으로 변환
        val originalBitmap = BitmapFactory.decodeResource(resources, R.drawable.original_image)
        // Create a 3x3 puzzle

        // Set puzzle pieces to GridView
        adapter = PuzzleAdapter(this, puzzlePieces)
        boardView.numColumns = 3
        boardView.adapter = adapter

        // Handle Shuffle button click event
        shuffleButton.setOnClickListener {
            shufflePuzzlePieces()
        }

        // Add GridView item click event
        boardView.setOnItemClickListener { _, _, position, _ ->
            slidePiece(position)
        }
    }

    private fun createPuzzle(rows: Int, cols: Int) {
        val originalBitmap = BitmapFactory.decodeResource(resources, R.drawable.original_image)
        puzzlePieces = createPuzzlePieces(originalBitmap, rows, cols).toMutableList()

        // GridView 설정
        boardView.numColumns = cols
        adapter = PuzzleAdapter(this, puzzlePieces)
        boardView.adapter = adapter
    }

    private fun createPuzzlePieces(bitmap: Bitmap, rows: Int, cols: Int): List<Bitmap?> {
        val pieceWidth = bitmap.width / cols
        val pieceHeight = bitmap.height / rows
        val pieces = mutableListOf<Bitmap?>()

        for (row in 0 until rows) {
            for (col in 0 until cols) {
                if (row == rows - 1 && col == cols - 1) {
                    // Set the last piece as an empty space
                    pieces.add(null)
                } else {
                    val piece = Bitmap.createBitmap(
                        bitmap,
                        col * pieceWidth,
                        row * pieceHeight,
                        pieceWidth,
                        pieceHeight
                    )
                    pieces.add(piece)
                }
            }
        }
        return pieces
    }

    private fun shufflePuzzlePieces() {
        puzzlePieces.shuffle()

        // Move the empty space (null) to the bottom-right corner
        val emptyIndex = puzzlePieces.indexOf(null)
        if (emptyIndex != -1) {
            val lastIndex = puzzlePieces.size - 1
            puzzlePieces[emptyIndex] = puzzlePieces[lastIndex]
            puzzlePieces[lastIndex] = null
        }

        adapter.notifyDataSetChanged()
    }
    private fun slidePiece(position: Int) {
        val gridSize = Math.sqrt(puzzlePieces.size.toDouble()).toInt()
        val emptyIndex = puzzlePieces.indexOf(null)

        // Check if the clicked piece is adjacent to the empty space
        if (isAdjacent(position, emptyIndex, gridSize)) {
            // Swap positions
            puzzlePieces[emptyIndex] = puzzlePieces[position]
            puzzlePieces[position] = null
            adapter.notifyDataSetChanged()
        }
    }

    private fun isAdjacent(pos1: Int, pos2: Int, gridSize: Int): Boolean {
        val row1 = pos1 / gridSize
        val col1 = pos1 % gridSize
        val row2 = pos2 / gridSize
        val col2 = pos2 % gridSize

        // Adjacent if the row or column differs by 1
        return (row1 == row2 && Math.abs(col1 - col2) == 1) ||
                (col1 == col2 && Math.abs(row1 - row2) == 1)
    }
}
